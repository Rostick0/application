<?

require_once './require.php';

?>